const fs = require('fs')
const {
smsg, getGroupAdmins, formatp, tanggal, formatDate, getTime, isUrl, await, sleep, clockString, msToDate, sort, toNumber, enumGetKey, runtime, fetchJson, getBuffer, jsonformat, delay, format, logic, generateProfilePicture, parseMention, getRandom, pickRandom, reSize
} = require('./lib/myfunction')

global.d = new Date()
global.calender = d.toLocaleDateString('id')

//General Settings
global.apikey = 'ptla_aORomnjMxKbutwJmXJmaB9bPORK7I0NyjAIxxtwhMCr' //Ganti pake apikey panel lu
global.capikey = 'ptlc_U5fwq86umF5wiwy8cI2VwTcP5jqBCi4X9KYmNW4o8X2' //Ganti Pake Capikey Panel Lu
global.domain = 'https://order.jasavirtex.pro'
global.eggsnya = '15' //Ganti Pake Eggs Panel Lu
global.location = '1' //Ganti Pake Location Panel Lu
global.prefa = ['','!','.',',','🐤','🗿']
global.Contributor = '254715448094','','',
global.NamaOwner = '𝕬𝕷𝕱𝕬' //BOT OWNER
global.sessionName = 'ryokunsession'
global.connect = true //CONNECT VIA CODE OR Qr Code
global.namabot = '𝕬𝕷𝕱𝕬𝕭𝕺𝕿 𝕸𝕰𝕿𝕬 𝐕3 ' //BOT NAME
global.author = '𝕬𝕷𝕱𝕬\n\n+254715448094' //AUTHOR NAME
global.packname = '𝐒𝐓𝐈𝐂𝐊𝐄𝐑 𝐁𝐘 𝕬𝕷𝕱𝕬𝕭𝕺𝕿 𝕸𝕰𝕿𝕬...' //STICKER PACK NAME
global.yt = 'https://chat.whatsapp.com/IQge5Gwm9aklwX02CSCKXN' //WHATSAPP GROUP URL
global.listr = ` │⬡ 1GB Cpu: 50% - 3.000/bln
 │⬡ 2GB Cpu: 70% - 5.000/bln
 │⬡ 3GB Cpu: 90% - 7.000/bln
 │⬡ 4GB Cpu: 110% - 9.000/bln
 │⬡ 5GB Cpu: 130% - 11.000/bln
 │⬡ 6GB Cpu: 150% - 13.000/bln
 │⬡ 7GB Cpu: 170% - 15.000/bln
 │⬡ 8GB Cpu: 200% - 17.000/bln`

global.country = `254`

global.system = {
    gmail: `alfamwangi64@gmail.com`,
}

   //Respon
global.mess = { // bagian ini gausah diganti
    Ingroup: 'Fatal Error! this feature only works in groups only.',
        admin: 'Opps! 𝕬𝕷𝕱𝕬𝕭𝕺𝕿 is not a group admin.Request denied.',
    owner: 'Opps! ,Only premium members are allowed to use this feature.Contact ALFA for more help.',
    Seller: 'Sorry! feature unavailable since you are not allowed to use it.',
     usingsetpp: 'Feature only accessible by my owner "ALFA", contact him fore more info.',
   Wait: 'kindly wait as i process your request....',
   success: 'Request successful...',
   Bugrespon: '> Bug sent successfully, kindly wait....'
}

// #@whiskeysockets/baileys ^6.3.0
global.autOwn = 'req(62-8S57547ms11).287p'
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
	require('fs').unwatchFile(file)
	console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
	delete require.cache[file]
	require(file)
})
